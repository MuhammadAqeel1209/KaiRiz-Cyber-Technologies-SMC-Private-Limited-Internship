from flask import Flask, request, jsonify, render_template
import numpy as np
import pandas as pd
import pickle

app = Flask(__name__)

with open('houseTraningData.pkl','rb') as file:
    model = pickle.load(file)


@app.route('/')
def home():
    return render_template('model.html')


@app.route('/predict', methods=['POST'])
def predict():

    CRIM = float(request.form['CRIM'])
    ZN = float(request.form['ZN'])
    INDUS = float(request.form['INDUS'])
    CHAS = int(request.form['CHAS'])
    NOX = float(request.form['NOX'])
    RM = float(request.form['RM'])
    AGE = float(request.form['AGE'])
    DIS = float(request.form['DIS'])
    RAD = int(request.form['RAD'])
    TAX = float(request.form['TAX'])
    PTRATIO = float(request.form['PTRATIO'])
    B = float(request.form['B'])
    LSTAT = float(request.form['LSTAT'])

   
    input_data = pd.DataFrame({
        'CRIM': [CRIM],
        'ZN': [ZN],
        'INDUS': [INDUS],
        'CHAS': [CHAS],
        'NOX': [NOX],
        'RM': [RM],
        'AGE': [AGE],
        'DIS': [DIS],
        'RAD': [RAD],
        'TAX': [TAX],
        'PTRATIO': [PTRATIO],
        'B': [B],
        'LSTAT': [LSTAT]
    })

    predicted_price = model.predict(input_data)[0]


    response = {'PredictedPrice': predicted_price}

    return render_template('model.html',result = response)

app.run(debug=True)
